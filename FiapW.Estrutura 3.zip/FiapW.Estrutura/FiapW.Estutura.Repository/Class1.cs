﻿namespace FiapW.Estutura.Repository
{
    public class Class1
    {

    }
}
