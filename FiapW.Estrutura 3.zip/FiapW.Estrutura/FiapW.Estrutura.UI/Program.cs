﻿// See https://aka.ms/new-console-template for more information
using FiapW.Estrutura.Controller;

UsuarioController usuario = new UsuarioController();
if(usuario.validarUsuario("felipe", "123"))
{
    Console.WriteLine("usuario valido");
}
else
{
    Console.WriteLine("Usuario nao validado");
}
